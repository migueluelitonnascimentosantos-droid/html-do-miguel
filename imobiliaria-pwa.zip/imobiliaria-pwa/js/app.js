// Registro do Service Worker (PWA)
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("sw.js")
      .then(() => console.log("SW registrado!"))
      .catch((err) => console.log("Erro no SW:", err));
  });
}

// Botão de instalação (beforeinstallprompt)
let eventoInstalar = null;
window.addEventListener("beforeinstallprompt", (e) => {
  e.preventDefault();
  eventoInstalar = e;
});
document.getElementById("btnInstalar").addEventListener("click", async () => {
  if (eventoInstalar) {
    eventoInstalar.prompt();
    await eventoInstalar.userChoice;
    eventoInstalar = null;
  } else {
    alert("Para instalar: use o menu do navegador > 'Adicionar à tela inicial'.");
  }
});

// Dados dos imóveis
const imoveis = [
  { nome: "Apartamento 2 quartos", local: "Centro", preco: "R$ 350.000", img: "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800", tipo: "Venda" },
  { nome: "Casa com piscina", local: "Jardim das Flores", preco: "R$ 720.000", img: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800", tipo: "Venda" },
  { nome: "Kitnet mobiliada", local: "Vila Nova", preco: "R$ 1.200/mês", img: "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=800", tipo: "Aluguel" },
  { nome: "Cobertura duplex", local: "Praia do Sol", preco: "R$ 1.250.000", img: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=800", tipo: "Venda" },
  { nome: "Sala comercial", local: "Zona Industrial", preco: "R$ 2.500/mês", img: "https://images.unsplash.com/photo-1497366216548-37526070297c?w=800", tipo: "Aluguel" },
  { nome: "Terreno 500m²", local: "Loteamento Verde", preco: "R$ 180.000", img: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=800", tipo: "Venda" }
];

const lista = document.getElementById("listaImoveis");
lista.innerHTML = imoveis.map((i) => `
  <div class="col-md-4">
    <div class="card h-100 shadow-sm">
      <img src="${i.img}" class="card-img-top" alt="${i.nome}" />
      <div class="card-body">
        <span class="badge bg-primary mb-2">${i.tipo}</span>
        <h5 class="card-title">${i.nome}</h5>
        <p class="text-muted mb-1">📍 ${i.local}</p>
        <p class="fw-bold text-success fs-5">${i.preco}</p>
        <button class="btn btn-outline-primary w-100" onclick="alert('Interesse registrado em: ${i.nome}')">Tenho interesse</button>
      </div>
    </div>
  </div>
`).join("");

// Formulário
document.getElementById("formContato").addEventListener("submit", (e) => {
  e.preventDefault();
  alert("Mensagem enviada! Retornaremos em breve. ✅");
  e.target.reset();
});
